' ==========================================
' PURE VBSCRIPT RETRO AI APPLICATION
' ==========================================
Dim userInput, aiEndpoint, payload, xmlHttp, responseText, cleanResponse

' Set up a welcoming message loop
MsgBox "AI CORE INITIALIZED." & vbCrLf & "Ready for system inquiry...", 64, "VBScript AI Interface"

Do
    ' 1. Capture the user text query using a native VBScript InputBox
    userInput = InputBox("Ask the AI Core a question or request a script:", "AI Terminal Input")
    
    ' If the user clicks Cancel or leaves it empty, exit the running program loop smoothly
    If userInput = "" Then Exit Do
    
    ' 2. Establish the secure cloud connection configuration
    aiEndpoint = "https://huggingface.co"
    
    ' Format the text query into a clean transmission package string
    payload = "{""inputs"": """ & userInput & """, ""parameters"": {""max_new_tokens"": 120, ""temperature"": 0.7}}"
    
    ' Create the system background network engine component
    Set xmlHttp = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    
    ' Open a secure transmission tunnel to the artificial mind pipeline
    xmlHttp.Open "POST", aiEndpoint, False
    xmlHttp.SetRequestHeader "Content-Type", "application/json"
    
    ' Fire the payload across your local internet network gateway
    On Error Resume Next
    xmlHttp.Send payload
    
    ' Check if the network connection was successful
    If Err.Number <> 0 Then
        MsgBox "SYSTEM_ERROR: Network link dropped or blocked by firewall.", 16, "Fatal Fault"
        On Error GoTo 0
        Exit Do
    End If
    On Error GoTo 0
    
    ' 3. Process the AI text response data strings
    If xmlHttp.Status = 200 Then
        responseText = xmlHttp.ResponseText
        
        ' Simple string isolation to clean up the raw data and pull out the answer text
        If InStr(responseText, "generated_text"":""") > 0 Then
            cleanResponse = Mid(responseText, InStr(responseText, "generated_text"":""") + 17)
            cleanResponse = Left(cleanResponse, InStr(cleanResponse, """") - 1)
            
            ' Strip out the echo prompt if the model repeats your question back to you
            cleanResponse = Replace(cleanResponse, userInput, "")
            cleanResponse = Trim(cleanResponse)
            
            ' Replace common code escape characters so it reads beautifully in the box
            cleanResponse = Replace(cleanResponse, "\n", vbCrLf)
            cleanResponse = Replace(cleanResponse, "\""", """")
        Else
            cleanResponse = "AI_CORE: Analysis complete, but response data format was unexpected."
        End If
        
        ' 4. Display the AI's response inside a standard Windows dialogue box
        MsgBox cleanResponse, 0, "AI Core Response"
    Else
        MsgBox "SYSTEM_ERROR: AI server busy or rate limited. Code: " & xmlHttp.Status, 48, "Server Warning"
    End If
    
    ' Clean up component memory allocations before starting the next turn
    Set xmlHttp = Nothing
Loop

MsgBox "AI Engine Terminated. System back to idle.", 64, "Core Offline"
